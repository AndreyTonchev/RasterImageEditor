#include "Image.hpp"
#include "ImageTypes/PPMImage.hpp"
#include "ImageTypes/PGMImage.hpp"
#include "ImageTypes/PBMImage.hpp"
